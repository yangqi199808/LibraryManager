create definer = root@localhost trigger student_user
    after insert
    on student
    for each row
BEGIN
INSERT INTO user(stu_id) SELECT stu_id FROM student;
END;

