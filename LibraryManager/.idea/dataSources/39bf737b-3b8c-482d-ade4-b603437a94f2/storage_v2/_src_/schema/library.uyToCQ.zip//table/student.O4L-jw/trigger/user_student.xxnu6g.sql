create definer = root@localhost trigger user_student
    before delete
    on student
    for each row
BEGIN
DELETE FROM user where stu_id = (select stu_id from student);
END;

